
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useNavigate, useParams, Link } from 'react-router-dom';
import { Plane, Calendar, MapPin, Share2, Plus, Users, Check, ChevronRight, MessageCircle, ArrowLeft, Clock } from 'lucide-react';
// Fix: Removed unused imports Response, TimeLabel, ResponseStatus, TimeWindow
import { Trip } from './types';
import TripForm from './components/TripForm';
import TripDetail from './components/TripDetail';
import ResponsePage from './components/ResponsePage';
import Welcome from './components/Welcome';

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="mobile-container overflow-x-hidden min-h-screen flex flex-col">
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="/new" element={<TripForm />} />
          <Route path="/trip/:id" element={<TripDetail />} />
          <Route path="/respond/:id" element={<ResponsePage />} />
        </Routes>
      </div>
    </HashRouter>
  );
};

export default App;
