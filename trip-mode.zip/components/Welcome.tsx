
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Plus, Plane, MapPin, Calendar, ChevronRight } from 'lucide-react';
import { Trip } from '../types';

const Welcome: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const saved = localStorage.getItem('trips');
    if (saved) setTrips(JSON.parse(saved));
  }, []);

  return (
    <div className="flex-1 flex flex-col p-6 pb-24">
      <header className="mb-10 mt-4">
        <h1 className="text-3xl font-bold text-slate-900">Trip Mode</h1>
        <p className="text-slate-500 mt-2">See more friends on every trip.</p>
      </header>

      {trips.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
          <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center">
            <Plane className="w-10 h-10 text-blue-500" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">No trips yet</h2>
            <p className="text-slate-500 max-w-xs mx-auto mt-2">
              Ready to coordinate? Create your first trip and share the link with friends.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">My Trips</h3>
          {trips.map(trip => (
            <Link 
              key={trip.id} 
              to={`/trip/${trip.id}`}
              className="block p-4 bg-white border border-slate-200 rounded-2xl shadow-sm hover:border-blue-300 transition-colors"
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center text-blue-600 font-bold mb-1">
                    <MapPin className="w-4 h-4 mr-1" />
                    {trip.city}
                  </div>
                  <div className="flex items-center text-slate-500 text-sm">
                    <Calendar className="w-4 h-4 mr-1" />
                    {new Date(trip.startDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} - {new Date(trip.endDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                  </div>
                </div>
                <ChevronRight className="text-slate-300" />
              </div>
            </Link>
          ))}
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 max-w-[480px] mx-auto p-6 bg-gradient-to-t from-white via-white to-transparent">
        <button 
          onClick={() => navigate('/new')}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl flex items-center justify-center space-x-2 shadow-lg shadow-blue-200 transition-all active:scale-95"
        >
          <Plus className="w-5 h-5" />
          <span>New Trip</span>
        </button>
      </div>
    </div>
  );
};

export default Welcome;
